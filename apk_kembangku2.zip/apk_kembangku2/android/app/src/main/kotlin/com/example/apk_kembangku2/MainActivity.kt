package com.example.apk_kembangku2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
