import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_testing/main.dart';

void main() {
  testWidgets('Test Debug Page widgets', (WidgetTester tester) async {
    await tester.pumpWidget(MyApp());

    
    final printButton = find.text('Print Debug Message');
    final logButton = find.text('Log Debug Message');
    final exceptionButton = find.text('Handle Exception');

    
    expect(printButton, findsOneWidget);
    expect(logButton, findsOneWidget);
    expect(exceptionButton, findsOneWidget);

    
    await tester.tap(printButton);
    await tester.tap(logButton);
    await tester.tap(exceptionButton);

    await tester.pump(); 
  });
}
