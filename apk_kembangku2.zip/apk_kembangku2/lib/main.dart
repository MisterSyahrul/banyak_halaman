import 'package:flutter/material.dart';
import 'package:logger/logger.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Debugging and Testing',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: DebugPage(),
    );
  }
}

// Halaman Debugging
class DebugPage extends StatelessWidget {
  final Logger logger = Logger();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Debugging and Logging')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              child: const Text('Print Debug Message'),
              onPressed: () {
                var x = 42;
                print('Nilai dari variabel x: $x');
              },
            ),
            ElevatedButton(
              child: const Text('Log Debug Message'),
              onPressed: () {
                logger.d('Pesan debug');
                logger.i('Pesan info');
                logger.w('Pesan peringatan');
                logger.e('Pesan error');
                logger.f('Pesan fatal');
              },
            ),
            ElevatedButton(
              child: const Text('Handle Exception'),
              onPressed: () {
                try {
                  throw Exception('Ini contoh pengecualian');
                } catch (e) {
                  logger.e('Terjadi error: $e');
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}
